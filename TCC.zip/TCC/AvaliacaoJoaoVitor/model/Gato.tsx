export class Gato {
    public id : string;
    public nome : string;
    public sexo: string;
    public datanascimento: string;
    public raca : string;
    public idade: string;
    
    constructor(obj?: Partial<Gato>) {
        if (obj) {
            this.id = obj.id
            this.nome = obj.nome
            this.raca = obj.raca
            this.sexo = obj.sexo
            this.datanascimento = obj.datanascimento
            this.idade = obj.idade
         }
    }

    toFirestore() {
        const gato =  {
                    id : this.id,
                    nome : this.nome,
                    raca : this.raca,
                    sexo : this.sexo,
                    datanascimento : this.datanascimento,
                    idade : this.idade
         }
         return gato
    }

   
    toString() {
        const Objeto = `{
            "id": "${this.id}",
            "nome": "${this.nome}",
            "raca": "${this.raca}",
            "sexo": "${this.sexo}",
            "datanascimento": "${this.datanascimento}"
            "idade": "${this.idade}"  
        }`
        return Objeto
    }
};