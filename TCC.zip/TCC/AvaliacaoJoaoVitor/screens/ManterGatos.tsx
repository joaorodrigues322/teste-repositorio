import React, { useEffect, useState } from "react";
import {
  KeyboardAvoidingView,
  Text,
  TouchableOpacity,
  View,
  Button,
  TextInput,
  ActivityIndicator,
} from "react-native";
import { useNavigation } from "@react-navigation/core";
import { auth, firestore } from "../firebase";
import meuestilo from "../meuestilo";
import { Gato } from "../model/Gato";
import DateTimePickerModal from "react-native-modal-datetime-picker";

const ManterGatos = () => {
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

  const [formGato, setFormGato] = useState<Partial<Gato>>({});
  const [isSaving, setIsSaving] = useState(false);
  const GatoRef = firestore.collection('Gato');
  const navigation = useNavigation();

  useEffect(() => {

  }, []);

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = (date) => {
    console.warn("A date has been picked: ", date);
    const formattedDate =date.getDate().toString().padStart(2, "0") + "/" + ((date.getMonth()+1).toString().padStart(2, "0")) + "/" + date.getFullYear();
    console.log(formattedDate)
    setFormGato({ ...formGato, datanascimento: formattedDate })
    hideDatePicker();
  };

  const limparFormulario = () => {
    setIsSaving(false);
    setFormGato({});
  };

  const cancelar = async () => {
    limparFormulario();
  }

  const salvar = async () => {
    setIsSaving(true); // Indica que o salvamento está em andamento
    const gatoRefComId = GatoRef.doc();
    const gato = new Gato(formGato);
    gato.id = gatoRefComId.id;
    console.log(gato)
    gatoRefComId.set(gato.toFirestore()).then(() => {
      alert("Gato" + gato.nome + " Adicionado com Sucesso");
      console.log("Gato" + gato);
      console.log("Gato ToString: " + gato.toString())
      limparFormulario();
    }).finally(() => {
      setIsSaving(false); // Indica que o salvamento foi concluído
    });
  };

  return (
    <KeyboardAvoidingView
      style={meuestilo.container}
      behavior="padding"
    >
      <View style={meuestilo.inputContainer}>
        <TextInput
          placeholder="Nome"
          value={formGato.nome}
          onChangeText={val => setFormGato({ ...formGato, nome: val })}
          style={meuestilo.input}
          editable={!isSaving} // Desabilita o campo enquanto o salvamento está ocorrendo
        />
        <TextInput
          placeholder="Sexo"
          value={formGato.sexo?.toString()}
          onChangeText={val => setFormGato({ ...formGato, sexo: val })}
          style={meuestilo.input}
          editable={!isSaving} // Desabilita o campo enquanto o salvamento está ocorrendo
        />
        <TextInput
          placeholder="Raca"
          value={formGato.raca}
          onChangeText={val => setFormGato({ ...formGato, raca: val })}
          style={meuestilo.input}
          editable={!isSaving} // Desabilita o campo enquanto o salvamento está ocorrendo
        />

<TextInput
          placeholder="ID"
          value={formGato.id}
          onChangeText={val => setFormGato({ ...formGato, id: val })}
          style={meuestilo.input}
          editable={!isSaving} // Desabilita o campo enquanto o salvamento está ocorrendo
        />

<TextInput
          placeholder="Idade"
          value={formGato.raca}
          onChangeText={val => setFormGato({ ...formGato, idade: val })}
          style={meuestilo.input}
          editable={!isSaving} // Desabilita o campo enquanto o salvamento está ocorrendo
        />

        {/* <TextInput
          placeholder="DataNascimento"
          value={formCachorro.datanascimento}
          onChangeText={val => setFormCachorro({ ...formCachorro, datanascimento: val })}
          style={meuestilo.input}
          editable={!isSaving} // Desabilita o campo enquanto o salvamento está ocorrendo
        /> */}
        <Text>Nascimento: {formGato.datanascimento}</Text>
        <Button title="Show Date Picker" onPress={showDatePicker} />
        <DateTimePickerModal
          isVisible={isDatePickerVisible}
          mode="date"
          onConfirm={handleConfirm}
          onCancel={hideDatePicker}
        />

      </View>

      <View style={meuestilo.buttonContainer}>
        <TouchableOpacity onPress={cancelar} style={meuestilo.button}>
          <Text style={meuestilo.buttonText}>Cancelar</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={salvar}
          style={[meuestilo.button, meuestilo.buttonOutline]}
          disabled={isSaving} // Desabilita o botão enquanto o salvamento está ocorrendo
        >
          {isSaving ? (
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <ActivityIndicator color="white" />
              <Text style={{ marginLeft: 5 }}>Aguarde ...</Text>
            </View>
          ) : (
            <Text style={meuestilo.buttonOutlineText}>Salvar</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default ManterGatos;